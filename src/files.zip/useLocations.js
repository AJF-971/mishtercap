import { useState, useEffect } from 'react';
import { supabase } from './supabaseClient'; // adjust to your actual client path

// Shared hook: fetches active locations, sorted for display.
// Used by both the dashboard filter chips and the intake form dropdown,
// so both always agree on what locations exist.
export function useLocations() {
  const [locations, setLocations] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;

    async function load() {
      const { data, error } = await supabase
        .from('locations')
        .select('id, label, sort_order')
        .eq('active', true)
        .order('sort_order', { ascending: true });

      if (!cancelled) {
        if (!error) setLocations(data);
        setLoading(false);
      }
    }

    load();
    return () => {
      cancelled = true;
    };
  }, []);

  return { locations, loading };
}
