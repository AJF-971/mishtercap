import { useState, useEffect } from 'react';
import { Sparkles, ShieldCheck, Hammer, Car, Armchair } from 'lucide-react';
import { supabase } from './supabaseClient'; // adjust to your actual client path

// Maps each service_categories.id to an icon + short label.
// Update this if you add/rename categories in the `service_categories` table.
export const SERVICE_ICON_MAP = {
  detailing: { icon: Sparkles, label: 'Detailing' },
  ppf: { icon: ShieldCheck, label: 'PPF & films' },
  dentrepair: { icon: Hammer, label: 'Dent repair' },
  bodyshop: { icon: Car, label: 'Body work' },
  upholstery: { icon: Armchair, label: 'Upholstery' },
};

// Fetches service_categories ordered by sort_order, so "primary" service
// for a job is just whichever of its service_types has the lowest sort_order.
export function useServiceCategories() {
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;

    async function load() {
      const { data, error } = await supabase
        .from('service_categories')
        .select('id, label, sort_order')
        .eq('active', true)
        .order('sort_order', { ascending: true });

      if (!cancelled) {
        if (!error) setCategories(data);
        setLoading(false);
      }
    }

    load();
    return () => {
      cancelled = true;
    };
  }, []);

  return { categories, loading };
}

// Given a job's service_types array and the ordered category list,
// returns { primary, rest } -- primary is whichever type sorts first.
export function splitPrimaryService(serviceTypes, orderedCategories) {
  if (!serviceTypes || serviceTypes.length === 0) {
    return { primary: null, rest: [] };
  }
  const orderIndex = Object.fromEntries(orderedCategories.map((c, i) => [c.id, i]));
  const sorted = [...serviceTypes].sort(
    (a, b) => (orderIndex[a] ?? 999) - (orderIndex[b] ?? 999)
  );
  return { primary: sorted[0], rest: sorted.slice(1) };
}
